# HashCode2k21
Javariati HashCode Team

## Top 3 squad Bolzano Hub
Python to be fasty fast

# 5 REASONS WHY: Mateo is the best
- [ ] He loves beets
- [ ] He plants apples
- [ ] His chicks are yellow
- [x] Hates Rossini
